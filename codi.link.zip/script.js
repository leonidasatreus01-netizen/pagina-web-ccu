const menuToggle = document.querySelector('.navbar__menu-toggle');
const menu = document.querySelector('.navbar-menu');

menuToggle.addEventListener('click', () => {
  menu.classList.toggle('navbar__menu--active');

  const isOpen = menu.classList.contains('navbar__menu--active');

  menuToggle.setAttribute('aria-expanded', isOpen);
});
